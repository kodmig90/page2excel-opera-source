export async function resetTabSelection(tabId: number): Promise<void> {
  await chrome.storage.session.remove([
    `selectedElement:${tabId}`,
    `similarElements:${tabId}`,
    `detectedFields:${tabId}`,
    `columns:${tabId}`,
    `preparedTable:${tabId}`,
  ])
}
