export type SelectionIdentity = { id: string; text: string }

export type RepeatedElementsWindow = Window & {
  __page2excelStructuralGroup?: WeakSet<Element>
  __page2excelStructuralSignature?: (element: Element) => string | null
  __page2excelTableCells?: (rows: Element[]) => Map<Element, Element[]>
  __page2excelSelectedElement?: Element
  __page2excelResolveRepeatedElements?: (
    tagName: string, classes: string[], selection?: SelectionIdentity,
  ) => Element[]
}

// Install in the isolated world before each stage: executeScript cannot carry imported closures.
export function installRepeatedElementResolver() {
  const pageWindow = window as RepeatedElementsWindow
  // Pure comparison helper: ignores values, classes, IDs, comments, and formatting whitespace.
  function structuralSignature(element: Element): string | null {
    let nodeCount = 0
    function visit(node: Element, depth: number): string | null {
      if (++nodeCount > 2000 || depth > 32) return null
      const parts = [node.tagName.toLowerCase(), '(']
      for (const child of Array.from(node.childNodes)) {
        if (child.nodeType === 1) {
          const nested = visit(child as Element, depth + 1)
          if (nested === null) return null
          parts.push(nested)
        } else if (child.nodeType === 3 && child.textContent?.trim()) {
          parts.push('#text;')
        }
      }
      parts.push(')')
      return parts.join('')
    }
    return visit(element, 0)
  }
  pageWindow.__page2excelStructuralSignature = structuralSignature
  pageWindow.__page2excelTableCells = (rows) => {
    const result = new Map<Element, Element[]>()
    const visited = new Set<Element>()
    for (const row of rows) {
      const parent = row.parentElement
      if (visited.has(parent ?? row)) continue
      visited.add(parent ?? row)
      // Include preceding/unmatched rows for span accounting, but export only resolved rows.
      const siblings = parent
        ? Array.from(parent.children).filter((element) => element.tagName.toLowerCase() === 'tr')
        : [row]
      const carried: ({ cell: Element; remaining: number } | undefined)[] = []
      siblings.forEach((sibling, rowIndex) => {
        const cells: Element[] = []
        carried.forEach((span, column) => {
          if (span && span.remaining > 0) {
            cells[column] = span.cell
            span.remaining--
          }
        })
        let column = 0
        for (const cell of Array.from(sibling.children)) {
          if (!['td', 'th'].includes(cell.tagName.toLowerCase())) continue
          while (cells[column]) column++
          const parsedRows = Number.parseInt(cell.getAttribute('rowspan') ?? '1', 10)
          const rowSpan = parsedRows === 0 ? siblings.length - rowIndex : Math.max(1, parsedRows || 1)
          // Colspan only reserves logical positions; it does not add extra field candidates.
          const colSpan = Math.min(1000, Math.max(1, Number.parseInt(cell.getAttribute('colspan') ?? '1', 10) || 1))
          for (let offset = 0; offset < colSpan; offset++) {
            cells[column + offset] = cell
            carried[column + offset] = { cell, remaining: rowSpan - 1 }
          }
          column += colSpan
        }
        result.set(sibling, cells)
      })
    }
    return result
  }
  pageWindow.__page2excelResolveRepeatedElements = (tagName, classes, selection) => {
    pageWindow.__page2excelStructuralGroup = new WeakSet()
    let exact: Element[] = []
    if (classes.length > 0) {
      exact = Array.from(document.getElementsByTagName(tagName)).filter((element) =>
        element.classList.length === classes.length &&
        classes.every((className) => element.classList.contains(className)),
      )
      if (exact.length !== 1) return exact
    }

    const isSelected = (element: Element) => {
      const text = element instanceof HTMLElement ? element.innerText : element.textContent
      return element.isConnected && element.tagName.toLowerCase() === tagName &&
        element.classList.length === classes.length &&
        classes.every((className) => element.classList.contains(className)) &&
        (!selection || (
          element.id === selection.id &&
          (text ?? '').replace(/\s+/g, ' ').trim().slice(0, 200) === selection.text
        ))
    }
    let selected = pageWindow.__page2excelSelectedElement
    if (!selected || !isSelected(selected)) {
      selected = undefined
      if (selection?.id) {
        const byId = document.getElementById(selection.id)
        if (byId && isSelected(byId)) selected = byId
      }
      if (!selected && selection) {
        const candidates = Array.from(document.getElementsByTagName(tagName)).filter(isSelected)
        // Ambiguous saved text cannot safely identify a parent.
        if (candidates.length === 1) selected = candidates[0]
      }
    }
    if (!selected?.parentElement) return exact
    if (classes.length > 0) {
      if (exact[0] !== selected || selected.children.length === 0) return exact
      const signature = structuralSignature(selected)
      if (signature === null) return exact
      const structural = Array.from(selected.parentElement.children).filter((element) =>
        element.tagName.toLowerCase() === tagName && structuralSignature(element) === signature,
      )
      if (structural.length > 1) {
        pageWindow.__page2excelStructuralGroup = new WeakSet(structural)
        return structural
      }
      return exact
    }
    return Array.from(selected.parentElement.children).filter(
      (element) => element.tagName.toLowerCase() === tagName,
    )
  }
}
