import type { RepeatedElementsWindow, SelectionIdentity } from './repeatedElements'

export type FieldCandidate = {
  id: string
  type: 'text' | 'link' | 'imageAlt' | 'imageSrc'
  selector: string
  occurrence: number
  sampleValue: string
  tableColumn?: number
  elementPath?: number[]
}

// The shared resolver is installed in the same isolated world before this function runs.
export function detectFields(tagName: string, classes: string[], selectedUrl: string, selection?: SelectionIdentity) {
  if (window.location.href !== selectedUrl) {
    return { status: 'pageChanged' as const }
  }

  const pageWindow = window as RepeatedElementsWindow
  const group = pageWindow.__page2excelResolveRepeatedElements!(tagName, classes, selection)
  const sample = group[0]

  if (!sample) return { status: 'notFound' as const }
  const root = sample
  const structural = pageWindow.__page2excelStructuralGroup?.has(root) ?? false
  const logicalCells = root.tagName.toLowerCase() === 'tr'
    ? pageWindow.__page2excelTableCells!(group).get(root)
    : undefined
  const scopes = logicalCells
    ? Array.from(new Set(logicalCells)).filter(Boolean).map((cell) => ({ root: cell, column: logicalCells.indexOf(cell) }))
    : [{ root, column: undefined }]
  let fieldRoot = root
  let tableColumn: number | undefined

  const fields: FieldCandidate[] = []
  const seen = new Set<string>()
  let truncated = false

  function addCandidate(
    element: Element,
    type: FieldCandidate['type'],
    rawValue: string | null,
  ) {
    const sampleValue = (rawValue ?? '').replace(/\s+/g, ' ').trim().slice(0, 300)
    if (!sampleValue) return

    const duplicateKey = `${tableColumn ?? ''}\u0000${type}\u0000${sampleValue}`
    if (seen.has(duplicateKey)) return
    seen.add(duplicateKey)

    if (fields.length === 30) {
      truncated = true
      return
    }

    const selector = element === fieldRoot
      ? ':scope'
      : `:scope ${element.tagName.toLowerCase()}${Array.from(element.classList)
          .sort()
          .map((className) => `.${CSS.escape(className)}`)
          .join('')}`
    const occurrence = element === fieldRoot
      ? 0
      : Array.from(fieldRoot.querySelectorAll(selector)).indexOf(element)
    const elementPath: number[] = []
    if (structural) {
      let current = element
      while (current !== fieldRoot && current.parentElement) {
        elementPath.unshift(Array.from(current.parentElement.children).indexOf(current))
        current = current.parentElement
      }
    }

    fields.push({
      id: `field-${fields.length + 1}`,
      type,
      selector,
      occurrence,
      sampleValue,
      ...(tableColumn === undefined ? {} : { tableColumn }),
      ...(structural ? { elementPath } : {}),
    })
  }

  for (const scope of scopes) {
    fieldRoot = scope.root
    tableColumn = scope.column
    for (const element of [fieldRoot, ...fieldRoot.querySelectorAll('*')]) {
      if (truncated) break

      const tag = element.tagName.toLowerCase()
      if (['script', 'style', 'noscript', 'template'].includes(tag)) continue

      if (tag === 'a') addCandidate(element, 'link', element.getAttribute('href'))

      const directText = Array.from(element.childNodes)
        .filter((node) => node.nodeType === 3)
        .map((node) => node.textContent ?? '')
        .join(' ')
      addCandidate(element, 'text', directText)

      if (tag === 'img') {
        addCandidate(element, 'imageAlt', element.getAttribute('alt'))
        addCandidate(element, 'imageSrc', element.getAttribute('src'))
      }
    }
  }

  if (fields.length === 0) return { status: 'noFields' as const }
  return { status: 'success' as const, fields, truncated, url: window.location.href }
}
