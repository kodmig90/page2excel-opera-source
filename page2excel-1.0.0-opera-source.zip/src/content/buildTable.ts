import type { FieldCandidate } from './detectFields'
import type { RepeatedElementsWindow, SelectionIdentity } from './repeatedElements'

// The shared resolver is installed in the same isolated world before this function runs.
export function buildTable(
  tagName: string,
  classes: string[],
  selectedUrl: string,
  fields: FieldCandidate[],
  selection?: SelectionIdentity,
) {
  if (window.location.href !== selectedUrl) {
    return { status: 'pageChanged' as const }
  }

  const cards = (window as RepeatedElementsWindow)
    .__page2excelResolveRepeatedElements!(tagName, classes, selection)

  if (cards.length === 0) return { status: 'noCards' as const }
  const tableCells = tagName.toLowerCase() === 'tr'
    ? (window as RepeatedElementsWindow).__page2excelTableCells!(cards)
    : undefined

  const foundValues = fields.map(() => false)
  const rows = cards.map((card) => fields.map((field, index) => {
    const fieldRoot = tableCells && field.tableColumn !== undefined
      ? tableCells.get(card)?.[field.tableColumn]
      : card
    let element = field.selector === ':scope'
      ? fieldRoot
      : fieldRoot?.querySelectorAll(field.selector)[field.occurrence]
    if (field.elementPath) {
      element = fieldRoot
      for (const childIndex of field.elementPath) element = element?.children[childIndex]
    }
    if (!element) return ''

    let value = ''
    if (field.type === 'text') {
      value = Array.from(element.childNodes)
        .filter((node) => node.nodeType === 3)
        .map((node) => node.textContent ?? '')
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim()
    } else if (field.type === 'link' && element instanceof HTMLAnchorElement) {
      value = element.getAttribute('href') ? element.href : ''
    } else if (field.type === 'imageAlt' && element instanceof HTMLImageElement) {
      value = element.getAttribute('alt')?.trim() ?? ''
    } else if (field.type === 'imageSrc' && element instanceof HTMLImageElement) {
      value = element.getAttribute('src') ? element.src : ''
    }

    if (value) foundValues[index] = true
    return value
  }))

  if (foundValues.some((found) => !found)) {
    return { status: 'fieldMissing' as const }
  }

  return { status: 'success' as const, rows, url: window.location.href }
}
