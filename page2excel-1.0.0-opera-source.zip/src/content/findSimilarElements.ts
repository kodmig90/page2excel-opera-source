import type { RepeatedElementsWindow, SelectionIdentity } from './repeatedElements'

// The shared resolver is installed in the same isolated world before this function runs.
export function findSimilarElements(
  tagName: string,
  classes: string[],
  selectedUrl: string,
  selection?: SelectionIdentity,
) {
  const highlightWindow = window as RepeatedElementsWindow & {
    __page2excelSimilarHighlightCleanup?: () => void
  }
  highlightWindow.__page2excelSimilarHighlightCleanup?.()

  if (window.location.href !== selectedUrl) {
    return { count: 0, url: window.location.href }
  }

  const matches = highlightWindow.__page2excelResolveRepeatedElements!(tagName, classes, selection)
  if (classes.length === 0 && matches.length === 0) {
    return { count: 0, url: window.location.href, insufficient: true }
  }

  if (matches.length > 0 && matches.length <= 500) {
    const overlays: HTMLElement[] = []
    const fragment = document.createDocumentFragment()

    for (const element of matches) {
      const rect = element.getBoundingClientRect()
      const overlay = document.createElement('div')
      overlay.style.cssText =
        'all: initial; position: fixed; pointer-events: none; z-index: 2147483647; ' +
        'outline: 2px solid #1a73e8; outline-offset: -2px;'
      overlay.style.left = `${rect.left}px`
      overlay.style.top = `${rect.top}px`
      overlay.style.width = `${rect.width}px`
      overlay.style.height = `${rect.height}px`
      fragment.append(overlay)
      overlays.push(overlay)
    }

    document.documentElement.append(fragment)

    function cleanup() {
      window.clearTimeout(timer)
      window.removeEventListener('scroll', cleanup, true)
      window.removeEventListener('resize', cleanup, true)
      window.removeEventListener('pagehide', cleanup, true)
      for (const overlay of overlays) overlay.remove()
      if (highlightWindow.__page2excelSimilarHighlightCleanup === cleanup) {
        delete highlightWindow.__page2excelSimilarHighlightCleanup
      }
    }

    const timer = window.setTimeout(cleanup, 3000)
    highlightWindow.__page2excelSimilarHighlightCleanup = cleanup
    window.addEventListener('scroll', cleanup, true)
    window.addEventListener('resize', cleanup, true)
    window.addEventListener('pagehide', cleanup, true)
  }

  return { count: matches.length, url: window.location.href }
}
