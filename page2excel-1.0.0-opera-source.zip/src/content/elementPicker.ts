/// <reference types="chrome" />

export type SelectedElement = {
  tagName: string
  id: string
  classes: string[]
  text: string
  url: string
  title: string
}

type PickerMessages = {
  selected: string
  cancelled: string
  error: string
  instructions: string
  elementTypes: Record<string, string>
  unknownElement: string
}

export const pickerTypeMessages: Record<string, string> = {
  a: 'elementTypeLink', button: 'elementTypeButton', img: 'elementTypeImage',
  table: 'elementTypeTable', thead: 'elementTypeTableHeader', tbody: 'elementTypeTableBody',
  tr: 'elementTypeTableRow', td: 'elementTypeTableCell', th: 'elementTypeHeaderCell',
  ul: 'elementTypeList', ol: 'elementTypeList', li: 'elementTypeListItem',
  input: 'elementTypeInput', select: 'elementTypeSelect', form: 'elementTypeForm',
  p: 'elementTypeParagraph', h1: 'elementTypeHeading', h2: 'elementTypeHeading',
  h3: 'elementTypeHeading', h4: 'elementTypeHeading', h5: 'elementTypeHeading', h6: 'elementTypeHeading',
  nav: 'elementTypeNavigation', section: 'elementTypeSection', article: 'elementTypeArticle',
  div: 'elementTypeBlock', span: 'elementTypeText',
}

// executeScript serializes this function, so all runtime helpers stay inside it.
export function startElementPicker(storageKey: string, messages: PickerMessages) {
  const pickerWindow = window as Window & {
    __page2excelPickerCleanup?: () => void
    __page2excelSelectedElement?: Element
  }

  pickerWindow.__page2excelPickerCleanup?.()
  delete pickerWindow.__page2excelSelectedElement

  let hoveredElement: Element | null = null
  let deeperElements: Element[] = []
  let toast: HTMLDivElement | null = null
  let toastTimer: number | undefined

  const highlight = document.createElement('div')
  highlight.style.cssText =
    'all: initial; position: fixed; display: none; pointer-events: none; ' +
    'z-index: 2147483647; outline: 2px solid #1a73e8; outline-offset: -2px;'
  document.documentElement.append(highlight)

  const overlayStyle =
    'all: initial; position: fixed; box-sizing: border-box; padding: 8px 12px; ' +
    'border-radius: 6px; background: #202124; color: #fff; ' +
    'font: 13px/1.4 system-ui, sans-serif; overflow-wrap: anywhere; ' +
    'max-width: calc(100vw - 16px); max-height: calc(100vh - 16px); overflow: hidden; ' +
    'pointer-events: none; z-index: 2147483647;'
  const instructions = document.createElement('div')
  instructions.style.cssText = overlayStyle +
    'right: 8px; bottom: 8px; padding: 12px 16px; font-size: 15px; white-space: pre-line;'
  instructions.textContent = messages.instructions
  const tooltip = document.createElement('div')
  tooltip.style.cssText = overlayStyle + 'display: none;'
  const typeLabel = document.createElement('div')
  typeLabel.style.cssText = 'all: initial; display: block; color: inherit; font: inherit; font-weight: 600;'
  const technicalLabel = document.createElement('div')
  technicalLabel.style.cssText = 'all: initial; display: block; color: inherit; font: 12px/1.4 monospace; overflow-wrap: anywhere;'
  tooltip.append(typeLabel, technicalLabel)
  document.documentElement.append(instructions, tooltip)

  function showToast(message: string) {
    toast?.remove()
    window.clearTimeout(toastTimer)
    toast = document.createElement('div')
    toast.setAttribute('role', 'status')
    toast.textContent = message
    toast.style.cssText =
      'all: initial; position: fixed; right: 16px; bottom: 16px; ' +
      'box-sizing: border-box; max-width: calc(100vw - 32px); padding: 10px 14px; ' +
      'border-radius: 8px; background: #202124; color: #fff; ' +
      'font: 14px/1.45 system-ui, sans-serif; overflow-wrap: anywhere; ' +
      'pointer-events: none; z-index: 2147483647;'
    document.documentElement.append(toast)
    toastTimer = window.setTimeout(() => {
      toast?.remove()
      toast = null
    }, 3000)
  }

  function updateHighlight() {
    if (!hoveredElement?.isConnected) {
      highlight.style.display = 'none'
      tooltip.style.display = 'none'
      return
    }

    const rect = hoveredElement.getBoundingClientRect()
    highlight.style.display = 'block'
    highlight.style.left = `${rect.left}px`
    highlight.style.top = `${rect.top}px`
    highlight.style.width = `${rect.width}px`
    highlight.style.height = `${rect.height}px`
    const tag = hoveredElement.tagName.toLowerCase()
    typeLabel.textContent = messages.elementTypes[tag] ?? messages.unknownElement
    technicalLabel.textContent = [tag, ...Array.from(hoveredElement.classList)].join('.')
    tooltip.style.display = 'block'
    const width = tooltip.offsetWidth
    const height = tooltip.offsetHeight
    let top = rect.bottom + 8
    if (top + height > window.innerHeight - 8) top = rect.top - height - 8
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8))
    top = Math.max(8, Math.min(top, window.innerHeight - height - 8))
    const instructionRect = instructions.getBoundingClientRect()
    if (
      left < instructionRect.right && left + width > instructionRect.left &&
      top < instructionRect.bottom && top + height > instructionRect.top
    ) {
      top = Math.max(8, instructionRect.top - height - 8)
    }
    tooltip.style.left = `${left}px`
    tooltip.style.top = `${top}px`
  }

  function onMouseMove(event: MouseEvent) {
    const target = event.composedPath()[0]
    hoveredElement = target instanceof Element ? target : null
    if (hoveredElement === document.documentElement) hoveredElement = document.body
    deeperElements = []
    updateHighlight()
  }

  function blockPageAction(event: Event) {
    event.preventDefault()
    event.stopImmediatePropagation()
  }

  const blockedEvents = [
    'pointerdown', 'pointerup', 'mousedown', 'mouseup',
    'auxclick', 'dblclick', 'contextmenu',
  ]

  function cleanup() {
    window.removeEventListener('mousemove', onMouseMove, true)
    window.removeEventListener('click', onClick, true)
    window.removeEventListener('keydown', onKeyDown, true)
    window.removeEventListener('scroll', updateHighlight, true)
    window.removeEventListener('resize', updateHighlight, true)
    window.removeEventListener('pagehide', cleanup, true)
    for (const type of blockedEvents) {
      window.removeEventListener(type, blockPageAction, true)
    }
    highlight.remove()
    instructions.remove()
    tooltip.remove()
    hoveredElement = null
    deeperElements = []
    toast?.remove()
    toast = null
    window.clearTimeout(toastTimer)
  }

  async function onClick(event: MouseEvent) {
    blockPageAction(event)
    if (event.button !== 0) return

    const element = hoveredElement ?? event.composedPath()[0]
    if (!(element instanceof Element) || !element.isConnected) return

    const text = element instanceof HTMLElement ? element.innerText : element.textContent
    const selection: SelectedElement = {
      tagName: element.tagName.toLowerCase(),
      id: element.id,
      classes: Array.from(element.classList),
      text: (text ?? '').replace(/\s+/g, ' ').trim().slice(0, 200),
      url: window.location.href,
      title: document.title,
    }

    cleanup()

    try {
      await chrome.storage.session.set({ [storageKey]: selection })
      pickerWindow.__page2excelSelectedElement = element
      showToast(messages.selected)
    } catch {
      showToast(messages.error)
    }
  }

  function onKeyDown(event: KeyboardEvent) {
    if (!['Escape', 'ArrowUp', 'ArrowDown'].includes(event.key)) return
    blockPageAction(event)
    if (event.key === 'Escape') {
      cleanup()
      showToast(messages.cancelled)
      return
    }
    if (!hoveredElement?.isConnected) return
    if (event.key === 'ArrowUp' && hoveredElement !== document.body) {
      const parent = hoveredElement.parentElement
      if (parent && parent !== document.documentElement) {
        deeperElements.push(hoveredElement)
        hoveredElement = parent
      }
    } else if (event.key === 'ArrowDown') {
      const deeper = deeperElements.pop()
      if (deeper?.isConnected) hoveredElement = deeper
    }
    updateHighlight()
  }

  pickerWindow.__page2excelPickerCleanup = cleanup
  window.addEventListener('mousemove', onMouseMove, true)
  window.addEventListener('click', onClick, true)
  window.addEventListener('keydown', onKeyDown, true)
  window.addEventListener('scroll', updateHighlight, true)
  window.addEventListener('resize', updateHighlight, true)
  window.addEventListener('pagehide', cleanup, true)
  for (const type of blockedEvents) {
    window.addEventListener(type, blockPageAction, { capture: true, passive: false })
  }
}
