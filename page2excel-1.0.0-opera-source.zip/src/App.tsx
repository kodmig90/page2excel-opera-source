/// <reference types="chrome" />

import { useEffect, useState } from 'react'
import { startElementPicker, pickerTypeMessages, type SelectedElement } from './content/elementPicker'
import { resetTabSelection } from './resetSelection'
import { findSimilarElements } from './content/findSimilarElements'
import { detectFields, type FieldCandidate } from './content/detectFields'
import { buildTable } from './content/buildTable'
import { installRepeatedElementResolver } from './content/repeatedElements'
import { generateCsv } from './export/csv'
import { downloadXlsx } from './export/xlsx'
import './App.css'

type OperationErrorMessage = 'analysisError' | 'pageAccessError'

function operationErrorMessage(error: unknown): OperationErrorMessage {
  const message = error instanceof Error ? error.message : String(error)
  return /cannot access|cannot be scripted|extensions gallery|not allowed to access|missing host permission/i.test(message)
    ? 'pageAccessError'
    : 'analysisError'
}

type PageInfo = {
  title: string
  url: string
  elementCount: number
}

type AnalysisState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; page: PageInfo }
  | { status: 'error'; message?: OperationErrorMessage }

type SimilarState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; count: number }
  | { status: 'insufficient' }
  | { status: 'pageChanged' }
  | { status: 'error'; message?: OperationErrorMessage }

type StoredSimilarResult = {
  count: number
  url: string
  tagName: string
  classes: string[]
}

type FieldsState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; fields: FieldCandidate[]; truncated: boolean }
  | { status: 'notFound' }
  | { status: 'noFields' }
  | { status: 'pageChanged' }
  | { status: 'error'; message?: OperationErrorMessage }

type StoredFieldsResult = {
  fields: FieldCandidate[]
  truncated: boolean
  url: string
  tagName: string
  classes: string[]
}

type ColumnConfiguration = {
  fieldId: string
  selected: boolean
  columnName: string
}

type PreparedTable = {
  columns: { fieldId: string; columnName: string }[]
  rows: string[][]
  url: string
  tagName: string
  classes: string[]
}

type TableState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; preview: PreparedTable }
  | { status: 'noCards' }
  | { status: 'fieldMissing' }
  | { status: 'pageChanged' }
  | { status: 'error'; message?: OperationErrorMessage }

function isValidPreparedTable(value: unknown): value is PreparedTable {
  if (!value || typeof value !== 'object') return false
  const table = value as Partial<PreparedTable>
  return typeof table.url === 'string' &&
    typeof table.tagName === 'string' &&
    Array.isArray(table.classes) &&
    table.classes.every((name) => typeof name === 'string') &&
    Array.isArray(table.columns) &&
    table.columns.length > 0 &&
    table.columns.every((column) =>
      typeof column?.fieldId === 'string' &&
      typeof column.columnName === 'string' && column.columnName.trim().length > 0,
    ) &&
    Array.isArray(table.rows) &&
    table.rows.length > 0 &&
    table.rows.every((row) =>
      Array.isArray(row) && row.length === table.columns?.length &&
      row.every((value) => typeof value === 'string'),
    )
}

function matchesSelection(
  record: { url: string; tagName: string; classes: string[] },
  selection: SelectedElement,
  tabUrl?: string,
) {
  return record.url === selection.url &&
    (!tabUrl || record.url === tabUrl) &&
    record.tagName === selection.tagName &&
    record.classes.length === selection.classes.length &&
    record.classes.every((name) => selection.classes.includes(name))
}

const fieldTypeMessages: Record<FieldCandidate['type'], string> = {
  text: 'fieldTypeText',
  link: 'fieldTypeLink',
  imageAlt: 'fieldTypeImageAlt',
  imageSrc: 'fieldTypeImageSrc',
}

function defaultColumns(fields: FieldCandidate[]): ColumnConfiguration[] {
  const totals = new Map<FieldCandidate['type'], number>()
  const indexes = new Map<FieldCandidate['type'], number>()

  for (const field of fields) {
    totals.set(field.type, (totals.get(field.type) ?? 0) + 1)
  }

  return fields.map((field) => {
    const index = (indexes.get(field.type) ?? 0) + 1
    indexes.set(field.type, index)
    const name = chrome.i18n.getMessage(fieldTypeMessages[field.type])

    return {
      fieldId: field.id,
      selected: true,
      columnName: (totals.get(field.type) ?? 0) > 1 ? `${name} ${index}` : name,
    }
  })
}

function App() {
  const [analysis, setAnalysis] = useState<AnalysisState>({ status: 'idle' })
  const [pickerStatus, setPickerStatus] = useState<'idle' | 'starting' | 'error'>('idle')
  const [pickerErrorMessage, setPickerErrorMessage] = useState<OperationErrorMessage>('analysisError')
  const [selectionPageChanged, setSelectionPageChanged] = useState(false)
  const [selectedElement, setSelectedElement] = useState<SelectedElement | null>(null)
  const [similar, setSimilar] = useState<SimilarState>({ status: 'idle' })
  const [fields, setFields] = useState<FieldsState>({ status: 'idle' })
  const [columns, setColumns] = useState<ColumnConfiguration[]>([])
  const [activeTabId, setActiveTabId] = useState<number | null>(null)
  const [table, setTable] = useState<TableState>({ status: 'idle' })
  const [tableSaveError, setTableSaveError] = useState(false)
  const [csvExportError, setCsvExportError] = useState(false)
  const [xlsxExportError, setXlsxExportError] = useState(false)
  const [xlsxExporting, setXlsxExporting] = useState(false)
  const [columnSaveError, setColumnSaveError] = useState(false)
  const [resettingSelection, setResettingSelection] = useState(false)
  const [resetSelectionError, setResetSelectionError] = useState(false)
  const isBusy =
    analysis.status === 'loading' ||
    pickerStatus === 'starting' ||
    similar.status === 'loading' ||
    fields.status === 'loading' ||
    table.status === 'loading' ||
    xlsxExporting || resettingSelection
  const canPrepare =
    fields.status === 'success' &&
    columns.length === fields.fields.length &&
    columns.some((column) => column.selected) &&
    columns.every((column) => !column.selected || column.columnName.trim().length > 0)
  const columnsDisabled = table.status === 'loading' || xlsxExporting

  useEffect(() => {
    let cancelled = false

    async function loadSelection() {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
        if (tab?.id === undefined) return

        const selectionKey = `selectedElement:${tab.id}`
        const similarKey = `similarElements:${tab.id}`
        const fieldsKey = `detectedFields:${tab.id}`
        const columnsKey = `columns:${tab.id}`
        const tableKey = `preparedTable:${tab.id}`
        const stored = await chrome.storage.session.get<
          Record<string, SelectedElement | StoredSimilarResult | StoredFieldsResult | ColumnConfiguration[] | PreparedTable>
        >([selectionKey, similarKey, fieldsKey, columnsKey, tableKey])
        if (cancelled) return

        setActiveTabId(tab.id)
        const selection = stored[selectionKey] as SelectedElement | undefined
        const previous = stored[similarKey] as StoredSimilarResult | undefined
        const previousFields = stored[fieldsKey] as StoredFieldsResult | undefined
        const previousColumns = stored[columnsKey] as ColumnConfiguration[] | undefined
        const previousTable = stored[tableKey] as PreparedTable | undefined
        if (selection && !matchesSelection(selection, selection, tab.url)) {
          setSelectionPageChanged(true)
          return
        }
        if (previousTable && !isValidPreparedTable(previousTable)) {
          setCsvExportError(true)
        }
        setSelectedElement(selection ?? null)
        if (
          selection && previous &&
          matchesSelection(previous, selection, tab.url)
        ) {
          setSimilar({ status: 'success', count: previous.count })
          if (previousFields && matchesSelection(previousFields, selection, tab.url)) {
            const validStoredColumns =
              Array.isArray(previousColumns) &&
              previousColumns.length === previousFields.fields.length &&
              previousFields.fields.every((field, index) =>
                previousColumns[index]?.fieldId === field.id &&
                typeof previousColumns[index]?.selected === 'boolean' &&
                typeof previousColumns[index]?.columnName === 'string',
              )
            const currentColumns = validStoredColumns
              ? previousColumns.map((column) => ({
                  ...column,
                  columnName: column.columnName.trim(),
                }))
              : defaultColumns(previousFields.fields)

            setFields({
              status: 'success',
              fields: previousFields.fields,
              truncated: previousFields.truncated,
            })
            setColumns(currentColumns)
            const selectedColumns = currentColumns
              .filter((column) => column.selected)
              .map((column) => ({
                fieldId: column.fieldId,
                columnName: column.columnName,
              }))
            if (
              isValidPreparedTable(previousTable) &&
              matchesSelection(previousTable, selection, tab.url) &&
              previousTable.columns.length === selectedColumns.length &&
              previousTable.columns.every((column, index) =>
                column.fieldId === selectedColumns[index].fieldId &&
                column.columnName === selectedColumns[index].columnName
              )
            ) {
              setTable({ status: 'success', preview: previousTable })
            }
            if (!validStoredColumns || currentColumns.some((column, index) =>
              column.columnName !== previousColumns?.[index].columnName
            )) {
              await chrome.storage.session.set({ [columnsKey]: currentColumns })
            }
          }
        }
      } catch {
        if (!cancelled) {
          setPickerErrorMessage('analysisError')
          setPickerStatus('error')
        }
      }
    }

    void loadSelection()
    return () => { cancelled = true }
  }, [])

  async function selectElement() {
    setPickerStatus('starting')
    setPickerErrorMessage('analysisError')
    setResetSelectionError(false)

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (tab?.id === undefined) {
        setPickerStatus('error')
        return
      }

      const key = `selectedElement:${tab.id}`
      await chrome.storage.session.remove([
        key, `similarElements:${tab.id}`, `detectedFields:${tab.id}`,
        `columns:${tab.id}`, `preparedTable:${tab.id}`,
      ])
      setSelectedElement(null)
      setSelectionPageChanged(false)
      setSimilar({ status: 'idle' })
      setFields({ status: 'idle' })
      setColumns([])
      setTable({ status: 'idle' })
      setTableSaveError(false)
      setCsvExportError(false)
      setXlsxExportError(false)
      await chrome.storage.session.setAccessLevel({
        accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS',
      })
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: startElementPicker,
        args: [key, {
          selected: chrome.i18n.getMessage('elementSelectedToast'),
          cancelled: chrome.i18n.getMessage('selectionCancelledToast'),
          error: chrome.i18n.getMessage('analysisError'),
          instructions: chrome.i18n.getMessage('pickerInstructions'),
          elementTypes: Object.fromEntries(Object.entries(pickerTypeMessages).map(([tag, key]) =>
            [tag, chrome.i18n.getMessage(key)],
          )),
          unknownElement: chrome.i18n.getMessage('elementTypePage'),
        }],
      })
      setPickerStatus('idle')
      window.close()
    } catch (error) {
      setPickerErrorMessage(operationErrorMessage(error))
      setPickerStatus('error')
    }
  }

  async function resetSelection() {
    setResettingSelection(true)
    setResetSelectionError(false)
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (tab?.id === undefined) throw new Error('Missing tab')
      await resetTabSelection(tab.id)
      setActiveTabId(tab.id)
      setSelectedElement(null)
      setSelectionPageChanged(false)
      setAnalysis({ status: 'idle' })
      setPickerStatus('idle')
      setSimilar({ status: 'idle' })
      setFields({ status: 'idle' })
      setColumns([])
      setTable({ status: 'idle' })
      setTableSaveError(false)
      setColumnSaveError(false)
      setCsvExportError(false)
      setXlsxExportError(false)
    } catch {
      setResetSelectionError(true)
    } finally {
      setResettingSelection(false)
    }
  }

  async function searchSimilar() {
    if (!selectedElement) return
    setFields({ status: 'idle' })
    setColumns([])
    setTable({ status: 'idle' })
    setTableSaveError(false)
    setCsvExportError(false)
    setXlsxExportError(false)

    setSimilar({ status: 'loading' })

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (tab?.id === undefined) {
        setSimilar({ status: 'error' })
        return
      }

      const key = `similarElements:${tab.id}`
      await chrome.storage.session.remove([
        key, `detectedFields:${tab.id}`, `columns:${tab.id}`,
        `preparedTable:${tab.id}`,
      ])
      await chrome.scripting.executeScript({
        target: { tabId: tab.id }, func: installRepeatedElementResolver,
      })
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: findSimilarElements,
        args: [selectedElement.tagName, selectedElement.classes, selectedElement.url, {
          id: selectedElement.id, text: selectedElement.text,
        }],
      })

      if (!injection?.result) {
        setSimilar({ status: 'error' })
        return
      }

      if (injection.result.url !== selectedElement.url) {
        setSimilar({ status: 'pageChanged' })
        return
      }

      if (injection.result.insufficient) {
        setSimilar({ status: 'insufficient' })
        return
      }

      const result: StoredSimilarResult = {
        count: injection.result.count,
        url: injection.result.url,
        tagName: selectedElement.tagName,
        classes: selectedElement.classes,
      }
      await chrome.storage.session.set({ [key]: result })
      setSimilar({ status: 'success', count: result.count })
    } catch (error) {
      setSimilar({ status: 'error', message: operationErrorMessage(error) })
    }
  }

  async function analyzeFields() {
    if (!selectedElement) return
    setFields({ status: 'loading' })
    setColumns([])
    setTable({ status: 'idle' })
    setTableSaveError(false)
    setCsvExportError(false)
    setXlsxExportError(false)

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (tab?.id === undefined) {
        setFields({ status: 'error' })
        return
      }

      const key = `detectedFields:${tab.id}`
      const columnsKey = `columns:${tab.id}`
      await chrome.storage.session.remove([
        key, columnsKey, `preparedTable:${tab.id}`,
      ])
      await chrome.scripting.executeScript({
        target: { tabId: tab.id }, func: installRepeatedElementResolver,
      })
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: detectFields,
        args: [selectedElement.tagName, selectedElement.classes, selectedElement.url, {
          id: selectedElement.id, text: selectedElement.text,
        }],
      })

      const result = injection?.result
      if (!result) {
        setFields({ status: 'error' })
      } else if (result.status === 'pageChanged') {
        setFields({ status: 'pageChanged' })
      } else if (result.status === 'notFound') {
        setFields({ status: 'notFound' })
      } else if (result.status === 'noFields') {
        setFields({ status: 'noFields' })
      } else if (result.status === 'success') {
        const newColumns = defaultColumns(result.fields)
        const stored: StoredFieldsResult = {
          fields: result.fields,
          truncated: result.truncated,
          url: result.url,
          tagName: selectedElement.tagName,
          classes: selectedElement.classes,
        }
        await chrome.storage.session.set({
          [key]: stored,
          [columnsKey]: newColumns,
        })
        setActiveTabId(tab.id)
        setColumns(newColumns)
        setFields({
          status: 'success',
          fields: result.fields,
          truncated: result.truncated,
        })
      } else {
        setFields({ status: 'error' })
      }
    } catch (error) {
      setFields({ status: 'error', message: operationErrorMessage(error) })
    }
  }

  function updateColumn(fieldId: string, changes: Partial<Pick<ColumnConfiguration, 'selected' | 'columnName'>>) {
    const updated = columns.map((column) =>
      column.fieldId === fieldId ? { ...column, ...changes } : column,
    )
    setColumns(updated)
    setTable({ status: 'idle' })
    setTableSaveError(false)
    setCsvExportError(false)
    setXlsxExportError(false)
    setColumnSaveError(false)

    if (activeTabId !== null) {
      void chrome.storage.session.set({ [`columns:${activeTabId}`]: updated })
        .catch(() => setColumnSaveError(true))
      void chrome.storage.session.remove(`preparedTable:${activeTabId}`)
        .catch(() => setColumnSaveError(true))
    }
  }

  async function prepareTable() {
    if (!canPrepare || !selectedElement || fields.status !== 'success') return
    setTable({ status: 'loading' })
    setTableSaveError(false)
    setCsvExportError(false)
    setXlsxExportError(false)

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (tab?.id === undefined) {
        setTable({ status: 'error' })
        return
      }

      const key = `preparedTable:${tab.id}`
      await chrome.storage.session.remove(key)

      const selectedColumns = columns.filter((column) => column.selected)
      const selectedFields = selectedColumns.map((column) =>
        fields.fields.find((field) => field.id === column.fieldId),
      )
      if (selectedFields.some((field) => !field)) {
        setTable({ status: 'error' })
        return
      }

      await chrome.scripting.executeScript({
        target: { tabId: tab.id }, func: installRepeatedElementResolver,
      })
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: buildTable,
        args: [
          selectedElement.tagName,
          selectedElement.classes,
          selectedElement.url,
          selectedFields as FieldCandidate[],
          { id: selectedElement.id, text: selectedElement.text },
        ],
      })

      const result = injection?.result
      if (!result) {
        setTable({ status: 'error' })
      } else if (result.status === 'pageChanged') {
        setTable({ status: 'pageChanged' })
      } else if (result.status === 'noCards') {
        setTable({ status: 'noCards' })
      } else if (result.status === 'fieldMissing') {
        setTable({ status: 'fieldMissing' })
      } else if (result.status === 'success') {
        const preview: PreparedTable = {
          columns: selectedColumns.map((column) => ({
            fieldId: column.fieldId,
            columnName: column.columnName.trim(),
          })),
          rows: result.rows,
          url: result.url,
          tagName: selectedElement.tagName,
          classes: selectedElement.classes,
        }
        setTable({ status: 'success', preview })
        const similarResult: StoredSimilarResult = {
          count: result.rows.length,
          url: result.url,
          tagName: selectedElement.tagName,
          classes: selectedElement.classes,
        }
        setSimilar({ status: 'success', count: similarResult.count })
        try {
          await chrome.storage.session.set({
            [key]: preview,
            [`similarElements:${tab.id}`]: similarResult,
          })
        } catch {
          setTableSaveError(true)
        }
      } else {
        setTable({ status: 'error' })
      }
    } catch (error) {
      setTable({ status: 'error', message: operationErrorMessage(error) })
    }
  }

  function downloadCsv() {
    setCsvExportError(false)
    try {
      if (table.status !== 'success') throw new Error('Missing table')
      const csv = generateCsv(table.preview.columns, table.preview.rows)
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }))
      const link = document.createElement('a')
      link.href = url
      link.download = 'page2excel.csv'
      try {
        document.body.append(link)
        link.click()
        window.setTimeout(() => URL.revokeObjectURL(url), 1000)
      } catch {
        URL.revokeObjectURL(url)
        throw new Error('Download failed')
      } finally {
        link.remove()
      }
    } catch {
      setCsvExportError(true)
    }
  }

  async function handleDownloadXlsx() {
    setXlsxExportError(false)
    if (table.status !== 'success') {
      setXlsxExportError(true)
      return
    }

    setXlsxExporting(true)
    try {
      await downloadXlsx(table.preview.columns, table.preview.rows)
    } catch {
      setXlsxExportError(true)
    } finally {
      setXlsxExporting(false)
    }
  }

  async function analyzePage() {
    setAnalysis({ status: 'loading' })

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

      if (tab?.id === undefined) {
        setAnalysis({ status: 'error' })
        return
      }

      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => ({
          title: document.title,
          url: window.location.href,
          elementCount: document.querySelectorAll('*').length,
        }),
      })

      if (!injection?.result) {
        setAnalysis({ status: 'error' })
        return
      }

      setAnalysis({ status: 'success', page: injection.result })
    } catch (error) {
      setAnalysis({ status: 'error', message: operationErrorMessage(error) })
    }
  }

  return (
    <main className="popup">
      <header className="popup__header">
        <h1>{chrome.i18n.getMessage('extensionName')}</h1>
        <span className="popup__version">{chrome.runtime.getManifest().version}</span>
      </header>

      <p className="popup__description">
        {chrome.i18n.getMessage('popupDescription')}
      </p>

      <p className="popup__instructions">
        {chrome.i18n.getMessage('selectionInstructions')}
      </p>
      <p className="popup__hint">
        {chrome.i18n.getMessage('selectionPopupHint')}
      </p>

      {selectionPageChanged && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('selectionPageChanged')}
        </p>
      )}

      <button
        className="primary-button popup__select-button"
        type="button"
        onClick={selectElement}
        disabled={isBusy}
      >
        {chrome.i18n.getMessage('selectElement')}
      </button>

      <button
        className="secondary-button popup__select-button"
        type="button"
        onClick={analyzePage}
        disabled={isBusy}
      >
        {chrome.i18n.getMessage('analyzePage')}
      </button>

      {pickerStatus === 'starting' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('startingSelection')}
        </p>
      )}

      {pickerStatus === 'error' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage(pickerErrorMessage)}
        </p>
      )}

      {selectedElement && (
        <section className="popup__selection" aria-live="polite">
          <h2>{chrome.i18n.getMessage('selectedElementTitle')}</h2>
          <button
            type="button"
            title={chrome.i18n.getMessage('resetSelection')}
            aria-label={chrome.i18n.getMessage('resetSelection')}
            onClick={resetSelection}
            disabled={isBusy}
          >
            {chrome.i18n.getMessage('resetSelection')}
          </button>
          <dl className="popup__result">
            <dt>{chrome.i18n.getMessage('elementTag')}</dt>
            <dd>{selectedElement.tagName}</dd>
            {selectedElement.id && (
              <>
                <dt>{chrome.i18n.getMessage('elementId')}</dt>
                <dd>{selectedElement.id}</dd>
              </>
            )}
            {selectedElement.classes.length > 0 && (
              <>
                <dt>{chrome.i18n.getMessage('elementClasses')}</dt>
                <dd>{selectedElement.classes.join(' ')}</dd>
              </>
            )}
            <dt>{chrome.i18n.getMessage('elementText')}</dt>
            <dd>{selectedElement.text || chrome.i18n.getMessage('noElementText')}</dd>
          </dl>
          <button
            className="primary-button popup__select-button"
            type="button"
            onClick={searchSimilar}
            disabled={isBusy}
          >
            {chrome.i18n.getMessage('findSimilarElements')}
          </button>
        </section>
      )}

      {similar.status === 'loading' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('searchingSimilarElements')}
        </p>
      )}

      {resetSelectionError && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('resetSelectionError')}
        </p>
      )}

      {similar.status === 'success' && (
        <section className="popup__selection" aria-live="polite">
          <h2>{chrome.i18n.getMessage(similar.count > 1 ? 'similarElementsTitle' : 'noRepeatedBlocksTitle')}</h2>
          <p className="popup__status">
            {chrome.i18n.getMessage('similarElementsFound', String(similar.count))}
          </p>
          {similar.count <= 1 && (
            <p className="popup__status">
              {chrome.i18n.getMessage('noSimilarElements')}
            </p>
          )}
          {similar.count > 500 && (
            <p className="popup__status">
              {chrome.i18n.getMessage('tooManySimilarElements')}
            </p>
          )}
          <button
            className="primary-button popup__select-button"
            type="button"
            onClick={similar.count > 1 ? analyzeFields : selectElement}
            disabled={isBusy}
          >
            {chrome.i18n.getMessage(similar.count > 1 ? 'detectFields' : 'selectElement')}
          </button>
        </section>
      )}

      {fields.status === 'loading' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('detectingFields')}
        </p>
      )}

      {fields.status === 'success' && (
        <section className="popup__selection" aria-live="polite">
          <h2>{chrome.i18n.getMessage('availableFields')}</h2>
          <ul className="popup__field-list">
            {fields.fields.map((field, index) => (
              <li
                key={field.id}
                className={!columns[index]?.selected ? 'popup__field--unselected' : undefined}
              >
                <label className="popup__field-choice">
                  <input
                    type="checkbox"
                    disabled={columnsDisabled}
                    checked={columns[index]?.selected ?? false}
                    onChange={(event) => updateColumn(field.id, {
                      selected: event.target.checked,
                    })}
                  />
                  <strong>{chrome.i18n.getMessage(fieldTypeMessages[field.type])}</strong>
                </label>
                <span className="popup__field-sample">{field.sampleValue}</span>
                <label className="popup__column-label">
                  {chrome.i18n.getMessage('columnName')}
                  <input
                    type="text"
                    disabled={columnsDisabled || !columns[index]?.selected}
                    value={columns[index]?.columnName ?? ''}
                    aria-invalid={columns[index]?.selected && !columns[index].columnName.trim()}
                    onChange={(event) => updateColumn(field.id, {
                      columnName: event.target.value,
                    })}
                    onBlur={() => {
                      const name = columns[index]?.columnName
                      if (name && name !== name.trim()) {
                        updateColumn(field.id, { columnName: name.trim() })
                      }
                    }}
                  />
                </label>
                {columns[index]?.selected && !columns[index].columnName.trim() && (
                  <span className="popup__status--error">
                    {chrome.i18n.getMessage('columnNameRequired')}
                  </span>
                )}
              </li>
            ))}
          </ul>
          {fields.truncated && (
            <p className="popup__status">
              {chrome.i18n.getMessage('fieldsLimited')}
            </p>
          )}
          <button
            className="primary-button popup__select-button"
            type="button"
            disabled={!canPrepare || isBusy}
            onClick={prepareTable}
          >
            {chrome.i18n.getMessage('prepareTable')}
          </button>
          {columnSaveError && (
            <p className="popup__status popup__status--error" role="alert">
              {chrome.i18n.getMessage('columnSaveError')}
            </p>
          )}
        </section>
      )}

      {table.status === 'loading' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('buildingTable')}
        </p>
      )}

      {table.status === 'success' && (
        <section className="popup__selection" aria-live="polite">
          <h2>{chrome.i18n.getMessage('tablePreview')}</h2>
          <p className="popup__status">
            {chrome.i18n.getMessage('tableSummary', [
              String(table.preview.rows.length),
              String(table.preview.columns.length),
            ])}
          </p>
          <button
            className="secondary-button popup__select-button"
            type="button"
            onClick={prepareTable}
            disabled={!canPrepare || isBusy}
          >
            {chrome.i18n.getMessage('refreshTable')}
          </button>
          <div className="popup__table-scroll">
            <table className="popup__table">
              <thead>
                <tr>
                  {table.preview.columns.map((column) => (
                    <th key={column.fieldId} scope="col">{column.columnName}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {table.preview.rows.slice(0, 10).map((row, index) => (
                  <tr key={index}>
                    {row.map((value, columnIndex) => (
                      <td key={table.preview.columns[columnIndex].fieldId}>{value}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {table.preview.rows.length > 10 && (
            <p className="popup__status">
              {chrome.i18n.getMessage('previewLimited', String(table.preview.rows.length))}
            </p>
          )}
          {table.preview.columns.length > 0 && (
            <>
              <p className="popup__status">
                {chrome.i18n.getMessage('fullExportNotice', String(table.preview.rows.length))}
              </p>
              <button
                className="primary-button popup__select-button"
                type="button"
                onClick={downloadCsv}
                disabled={isBusy}
              >
                {chrome.i18n.getMessage('downloadCsv')}
              </button>
              <button
                className="primary-button popup__select-button"
                type="button"
                onClick={handleDownloadXlsx}
                disabled={isBusy}
              >
                {chrome.i18n.getMessage(xlsxExporting ? 'preparingXlsx' : 'downloadXlsx')}
              </button>
            </>
          )}
          {tableSaveError && (
            <p className="popup__status popup__status--error" role="alert">
              {chrome.i18n.getMessage('tableSaveError')}
            </p>
          )}
        </section>
      )}

      {csvExportError && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('csvExportError')}
        </p>
      )}

      {xlsxExportError && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('xlsxExportError')}
        </p>
      )}

      {table.status === 'noCards' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('noRepeatedElements')}
        </p>
      )}

      {table.status === 'fieldMissing' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('selectedFieldMissing')}
        </p>
      )}

      {table.status === 'pageChanged' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage('selectionPageChanged')}
        </p>
      )}

      {table.status === 'error' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage(table.message ?? 'analysisError')}
        </p>
      )}

      {fields.status === 'notFound' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('selectedElementMissing')}
        </p>
      )}

      {fields.status === 'noFields' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('noUsefulFields')}
        </p>
      )}

      {fields.status === 'pageChanged' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('selectionPageChanged')}
        </p>
      )}

      {fields.status === 'error' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage(fields.message ?? 'analysisError')}
        </p>
      )}

      {similar.status === 'insufficient' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('elementHasNoClasses')}
        </p>
      )}

      {similar.status === 'pageChanged' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('selectionPageChanged')}
        </p>
      )}

      {similar.status === 'error' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage(similar.message ?? 'analysisError')}
        </p>
      )}

      {analysis.status === 'loading' && (
        <p className="popup__status" role="status">
          {chrome.i18n.getMessage('analyzingPage')}
        </p>
      )}

      {analysis.status === 'success' && (
        <dl className="popup__result" aria-live="polite">
          <dt>{chrome.i18n.getMessage('pageTitle')}</dt>
          <dd>{analysis.page.title || chrome.i18n.getMessage('untitledPage')}</dd>
          <dt>{chrome.i18n.getMessage('pageUrl')}</dt>
          <dd>{analysis.page.url}</dd>
          <dt>{chrome.i18n.getMessage('domElementCount')}</dt>
          <dd>{analysis.page.elementCount}</dd>
        </dl>
      )}

      {analysis.status === 'error' && (
        <p className="popup__status popup__status--error" role="alert">
          {chrome.i18n.getMessage(analysis.message ?? 'analysisError')}
        </p>
      )}
    </main>
  )
}

export default App
