type CsvColumn = { columnName: string }

export function generateCsv(columns: CsvColumn[], rows: string[][]): string {
  if (
    !Array.isArray(columns) || columns.length === 0 ||
    !columns.every((column) => typeof column?.columnName === 'string' && column.columnName.trim()) ||
    !Array.isArray(rows) || rows.length === 0 ||
    !rows.every((row) =>
      Array.isArray(row) && row.length === columns.length &&
      row.every((value) => typeof value === 'string'),
    )
  ) {
    throw new Error('Invalid CSV data')
  }

  const quote = (value: string) => `"${value.replaceAll('"', '""')}"`
  const lines = [
    columns.map((column) => quote(column.columnName)).join(','),
    ...rows.map((row) => row.map(quote).join(',')),
  ]

  return `\uFEFF${lines.join('\r\n')}\r\n`
}
