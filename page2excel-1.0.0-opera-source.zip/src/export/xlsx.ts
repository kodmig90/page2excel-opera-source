import type { SheetData } from 'write-excel-file/browser'

type XlsxColumn = { columnName: string }

export function prepareXlsxData(columns: XlsxColumn[], rows: string[][]): SheetData {
  if (
    !Array.isArray(columns) || columns.length === 0 ||
    !columns.every((column) => typeof column?.columnName === 'string' && column.columnName.trim()) ||
    !Array.isArray(rows) || rows.length === 0 ||
    !rows.every((row) =>
      Array.isArray(row) && row.length === columns.length &&
      row.every((value) => typeof value === 'string'),
    )
  ) {
    throw new Error('Invalid XLSX data')
  }

  return [
    columns.map((column) => ({ value: column.columnName, type: String, fontWeight: 'bold' })),
    ...rows.map((row) => row.map((value) => ({ value, type: String }))),
  ]
}

export async function downloadXlsx(columns: XlsxColumn[], rows: string[][]): Promise<void> {
  const sheetData = prepareXlsxData(columns, rows)
  const { default: writeExcelFile } = await import('write-excel-file/browser')
  await writeExcelFile(sheetData, { sheet: 'Page2Excel' }).toFile('page2excel.xlsx')
}
