# Page2Excel 1.0.0 - Opera moderator build instructions

Source commit: 19af0e0018be617c2e1781bb0eead88cdb0c1919
Environment: Node.js 24.15.0, npm 11.12.1
Package version: 1.0.0; package-lock.json format: 3.

Extract this archive into an empty directory. Run the following commands
in its root (where package.json is located), using the versions above:

    npm ci
    npm run build
    npm run lint
    npm test

On Windows PowerShell, npm.cmd may be used instead of npm.
Internet access to the npm registry is required for npm ci. Install development
dependencies too; do not use --omit=dev or NODE_ENV=production during installation.
Do not run npm update or regenerate package-lock.json. The lockfile records exact
dependency versions, registry URLs and integrity hashes.

The production output is dist/. manifest.config.ts is the source manifest,
imported by vite.config.ts and processed by @crxjs/vite-plugin. There is no
source manifest.json: dist/manifest.json is generated during the build.
Expected manifest: manifest_version 3, version 1.0.0, default_locale en,
permissions activeTab, scripting, storage; action.default_popup index.html.
Load dist as an unpacked extension to test the result.

Runtime output includes index.html, manifest.json, assets/, icons/ and _locales/.
To package it, place the CONTENTS of dist at the ZIP root, not the dist folder.
The runtime manifest.json must be at the ZIP root. Do not include the source
package or these instructions in the installed extension.

The separate, unchanged Chrome runtime package is page2excel-1.0.0-chrome.zip.
SHA-256:
476FE45D06F66F3928B7D28065DD2AE3E10A1D136EE546696388C64811266983
It is not included here. ZIP timestamps and compression may differ when
repackaged; compare uncompressed file contents for build correspondence.

Package contents:
- src/: readable application TypeScript/TSX and CSS.
- public/: used RU/EN locale files and extension PNG icons.
- tests/: all six test files invoked by npm test.
- Root: HTML entry point, package and lock files, source manifest, Vite,
  TypeScript and ESLint configurations, and these instructions.
Third-party dependencies are obtained through npm ci using package-lock.json;
they are not vendored into this source archive.

Validation during packaging:
- npm run build: passed.
- npm run lint: passed.
- npm test: passed, 28/28 tests.
Checks used existing installed dependencies. No installation or update was
performed while preparing this archive; a fresh npm ci run was not performed.
Source and configuration files were not modified.