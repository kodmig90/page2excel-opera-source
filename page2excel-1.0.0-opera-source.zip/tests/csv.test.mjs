import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

const source = readFileSync(new URL('../src/export/csv.ts', import.meta.url), 'utf8')
const output = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS },
}).outputText
const context = { exports: {} }
vm.runInNewContext(output, context)
const { generateCsv } = context.exports

test('exports every row and column with quoted values and CRLF separators', () => {
  const csv = generateCsv(
    [{ columnName: 'Name' }, { columnName: 'URL' }],
    [['Book', 'https://example.test/book'], ['Second', '']],
  )

  assert.equal(csv, '\uFEFF"Name","URL"\r\n"Book","https://example.test/book"\r\n"Second",""\r\n')
})

test('keeps Russian text, commas, quotes, and embedded line breaks', () => {
  const csv = generateCsv(
    [{ columnName: 'Название' }, { columnName: 'Описание' }],
    [['Книга, "моя"', 'Первая строка\nВторая строка']],
  )

  assert.equal(csv, '\uFEFF"Название","Описание"\r\n"Книга, ""моя""","Первая строка\nВторая строка"\r\n')
  assert.deepEqual([...Buffer.from(csv, 'utf8').subarray(0, 3)], [0xef, 0xbb, 0xbf])
})

test('rejects absent or malformed table data', () => {
  assert.throws(() => generateCsv([], [['value']]))
  assert.throws(() => generateCsv([{ columnName: 'Name' }], []))
  assert.throws(() => generateCsv([{ columnName: 'Name' }], [['a', 'b']]))
  assert.throws(() => generateCsv([{ columnName: 'Name' }], [[null]]))
})
