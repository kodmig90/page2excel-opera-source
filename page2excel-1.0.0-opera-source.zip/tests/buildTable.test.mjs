import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

const pageUrl = 'https://example.test/books/'

function injectedFunction(path, name) {
  const source = readFileSync(new URL(path, import.meta.url), 'utf8')
  const output = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS },
  }).outputText
  const context = { exports: {} }
  vm.runInNewContext(output, context)
  return context.exports[name].toString()
}

const detectSource = injectedFunction('../src/content/detectFields.ts', 'detectFields')
const buildSource = injectedFunction('../src/content/buildTable.ts', 'buildTable')
const findSource = injectedFunction('../src/content/findSimilarElements.ts', 'findSimilarElements')
const installSource = injectedFunction('../src/content/repeatedElements.ts', 'installRepeatedElementResolver')

class ElementNode {
  constructor(tag, classes = [], attributes = {}) {
    this.tagName = tag.toUpperCase()
    this.nodeType = 1
    this.classes = classes
    this.attributes = attributes
    this.childNodes = []
    this.children = []
    this.isConnected = true
    this.id = attributes.id ?? ''
    this.style = {}
    this.classList = {
      length: classes.length,
      contains: (name) => classes.includes(name),
      [Symbol.iterator]: function* () { yield* classes },
    }
  }

  append(child) {
    child.parentElement = this
    this.children.push(child)
    this.childNodes.push(child)
    return child
  }

  addText(value) {
    this.childNodes.push({ nodeType: 3, textContent: value })
    return this
  }

  getAttribute(name) {
    return this.attributes[name] ?? null
  }

  get innerText() {
    return this.childNodes.map((node) => node.nodeType === 3 ? node.textContent : node.innerText).join(' ')
  }

  getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 20 } }
  remove() { this.isConnected = false }

  querySelectorAll(selector) {
    const parsed = selector.match(/^:scope ([a-z][\w-]*)((?:\.[\w-]+)*)$/i)
    assert.ok(parsed || selector === '*', `Unexpected selector: ${selector}`)
    const wantedClasses = parsed?.[2].split('.').filter(Boolean) ?? []
    const matches = []

    function visit(parent) {
      for (const child of parent.children) {
        if (selector === '*' || (
          child.tagName.toLowerCase() === parsed[1] &&
          wantedClasses.every((name) => child.classes.includes(name))
        )) matches.push(child)
        visit(child)
      }
    }

    visit(this)
    return matches
  }
}

class AnchorNode extends ElementNode {
  get href() { return new URL(this.getAttribute('href'), pageUrl).href }
}

class ImageNode extends ElementNode {
  get src() { return new URL(this.getAttribute('src'), pageUrl).href }
}

function card(title, price) {
  const root = new ElementNode('article', ['product_pod'])
  root.append(new AnchorNode('a', ['title'], { href: 'catalogue/book.html' }))
    .addText(`  ${title}  `)
  if (price !== null) root.append(new ElementNode('p', ['price']).addText(price))
  root.append(new ImageNode('img', ['cover'], {
    alt: 'Book cover', src: 'images/cover.jpg',
  }))
  return root
}

function page(cards, url = pageUrl, selected) {
  const context = {
    window: {
      location: { href: url }, __page2excelSelectedElement: selected,
      setTimeout: () => 1, clearTimeout() {}, addEventListener() {}, removeEventListener() {},
    },
    document: {
      getElementsByTagName: (tag) => cards.filter((card) => card.tagName.toLowerCase() === tag),
      getElementById: (id) => cards.find((card) => card.id === id),
      createElement: (tag) => new ElementNode(tag),
      createDocumentFragment: () => ({ append() {} }),
      documentElement: { append() {} },
    },
    CSS: { escape: (name) => name },
    HTMLAnchorElement: AnchorNode,
    HTMLImageElement: ImageNode,
    HTMLElement: ElementNode,
  }
  vm.runInNewContext(`(${installSource})()`, context)
  return {
    find: vm.runInNewContext(`(${findSource})`, context),
    detect: vm.runInNewContext(`(${detectSource})`, context),
    build: vm.runInNewContext(`(${buildSource})`, context),
  }
}

test('rebuilding after load more and removal uses the current DOM with the same fields', () => {
  const cards = Array.from({ length: 10 }, (_, index) => card(`Book ${index}`, `$${index}`))
  const { detect, build } = page(cards)
  const fields = detect('article', ['product_pod'], pageUrl).fields
    .filter((field) => field.type === 'text')
  const collect = () => build('article', ['product_pod'], pageUrl, fields)
  assert.equal(collect().rows.length, 10)

  cards.push(...Array.from({ length: 10 }, (_, index) => card(`Book ${index + 10}`, `$${index + 10}`)))
  const expanded = collect()
  assert.equal(expanded.status, 'success')
  assert.equal(expanded.rows.length, 20)
  assert.deepEqual(Array.from(expanded.rows[19]), ['Book 19', '$19'])

  cards.splice(4)
  const reduced = collect()
  assert.equal(reduced.rows.length, 4)
  assert.deepEqual(Array.from(reduced.rows[3]), ['Book 3', '$3'])
})

test('rebuilding preserves empty individual fields and reports a field lost from all cards', () => {
  const cards = [card('A', '$10'), card('B', '$20')]
  const { detect, build } = page(cards)
  const fields = detect('article', ['product_pod'], pageUrl).fields
    .filter((field) => field.type === 'text')
  cards[1] = card('B', null)
  const partial = build('article', ['product_pod'], pageUrl, fields)
  assert.equal(partial.status, 'success')
  assert.deepEqual(Array.from(partial.rows[1]), ['B', ''])
  cards[0] = card('A', null)
  assert.equal(build('article', ['product_pod'], pageUrl, fields).status, 'fieldMissing')
})

test('classless tbody rows use the same group for search, field samples, and table rows', () => {
  const thead = new ElementNode('thead')
  const header = thead.append(new ElementNode('tr'))
  header.append(new ElementNode('th').addText('ID'))
  header.append(new ElementNode('th').addText('Name'))
  const tbody = new ElementNode('tbody')
  const first = tbody.append(new ElementNode('tr'))
  first.append(new ElementNode('td').addText('1'))
  first.append(new ElementNode('td').addText('Product A'))
  const second = tbody.append(new ElementNode('tr'))
  second.append(new ElementNode('td').addText('2'))
  second.append(new ElementNode('td').addText('Product B'))
  const other = new ElementNode('tbody').append(new ElementNode('tr'))
  other.append(new ElementNode('td').addText('99'))
  other.append(new ElementNode('td').addText('Other product'))
  const identity = { id: '', text: '1 Product A' }

  // Verify both the live picker reference and restoration from saved identity.
  for (const selected of [first, undefined]) {
    const { find, detect, build } = page([header, first, second, other], pageUrl, selected)
    const similar = find('tr', [], pageUrl, identity)
    assert.equal(similar.count, 2)
    const detection = detect('tr', [], pageUrl, identity)
    assert.equal(detection.status, 'success')
    assert.deepEqual(Array.from(detection.fields, (field) => field.sampleValue), ['1', 'Product A'])
    const result = build('tr', [], pageUrl, detection.fields, identity)
    assert.equal(result.status, 'success')
    assert.equal(result.rows.length, similar.count)
    assert.deepEqual(Array.from(result.rows, (row) => Array.from(row)), [['1', 'Product A'], ['2', 'Product B']])
  }
})

test('ten obfuscated sibling blocks produce correctly mapped fields and ten table rows', () => {
  const container = new ElementNode('div')
  const products = Array.from({ length: 10 }, (_, index) => {
    const root = container.append(new ElementNode('div', [`block-${index}`], { id: `product-${index}` }))
    root.append(new ElementNode('div', [`name-${index}`]).addText(`Product ${index}`))
    root.append(new ElementNode('div', [`category-${index}`]).addText('laptops'))
    root.append(new ElementNode('div', [`price-${index}`]).addText(`$${index * 10}`))
    return root
  })
  const ad = container.append(new ElementNode('div', ['advertisement']))
  ad.append(new ElementNode('p').addText('Do not export'))
  const identity = { id: products[0].id, text: products[0].innerText }
  for (const selected of [products[0], undefined]) {
    const { find, detect, build } = page([...products, ad], pageUrl, selected)
    assert.equal(find('div', ['block-0'], pageUrl, identity).count, 10)
    const detection = detect('div', ['block-0'], pageUrl, identity)
    assert.equal(detection.status, 'success')
    assert.deepEqual(Array.from(detection.fields, (field) => field.sampleValue), ['Product 0', 'laptops', '$0'])
    const result = build('div', ['block-0'], pageUrl, detection.fields, identity)
    assert.equal(result.status, 'success')
    assert.deepEqual(Array.from(result.rows, (row) => Array.from(row)),
      products.map((_, index) => [`Product ${index}`, 'laptops', `$${index * 10}`]))
  }
})

test('builds every row, preserves duplicates, fills missing values, and resolves URLs', () => {
  const cards = [card('Same book', ' £51.77 '), card('Same book', ' £51.77 '), card('Other book', null)]
  const { detect, build } = page(cards)
  const detection = detect('article', ['product_pod'], pageUrl)
  assert.equal(detection.status, 'success')

  const values = ['Same book', '£51.77', 'catalogue/book.html', 'Book cover', 'images/cover.jpg']
  const fields = values.map((value) => detection.fields.find((field) => field.sampleValue === value))
  assert.ok(fields.every(Boolean))

  const result = build('article', ['product_pod'], pageUrl, fields)
  assert.equal(result.status, 'success')
  assert.equal(result.rows.length, 3)
  assert.deepEqual([...result.rows[0]], [...result.rows[1]])
  assert.equal(result.rows[0][0], 'Same book')
  assert.equal(result.rows[0][1], '£51.77')
  assert.equal(result.rows[2][1], '')
  assert.equal(result.rows[0][2], 'https://example.test/books/catalogue/book.html')
  assert.equal(result.rows[0][3], 'Book cover')
  assert.equal(result.rows[0][4], 'https://example.test/books/images/cover.jpg')
})

function tableRow(parent, values, spans = {}) {
  const row = parent.append(new ElementNode('tr'))
  values.forEach((value, index) => row.append(new ElementNode('td', [], spans[index] ?? {}).addText(value)))
  return row
}

function collectTable(rows) {
  const identity = { id: '', text: rows[0].innerText.replace(/\s+/g, ' ').trim() }
  const { detect, build } = page(rows, pageUrl, rows[0])
  const detection = detect('tr', [], pageUrl, identity)
  assert.equal(detection.status, 'success')
  const result = build('tr', [], pageUrl, detection.fields, identity)
  assert.equal(result.status, 'success')
  return { fields: detection.fields, rows: Array.from(result.rows, (row) => Array.from(row)) }
}

test('rowspan categories stay in their columns and expire before the next group', () => {
  const tbody = new ElementNode('tbody')
  const rows = [
    tableRow(tbody, ['Laptops', 'A', '$10'], { 0: { rowspan: '3' } }),
    tableRow(tbody, ['B', '$20']),
    tableRow(tbody, ['C', '$30']),
    tableRow(tbody, ['Phones', 'D', '$40'], { 0: { rowspan: '2' } }),
    tableRow(tbody, ['E', '$50']),
  ]
  const result = collectTable(rows)
  assert.equal(result.fields.length, 3)
  assert.deepEqual(result.rows, [
    ['Laptops', 'A', '$10'], ['Laptops', 'B', '$20'], ['Laptops', 'C', '$30'],
    ['Phones', 'D', '$40'], ['Phones', 'E', '$50'],
  ])
})

test('a middle th rowspan preserves surrounding columns and missing values', () => {
  const tbody = new ElementNode('tbody')
  const first = tableRow(tbody, ['A', 'Shared', '$10'], { 1: { rowspan: '2' } })
  first.children[1].tagName = 'TH'
  const second = tableRow(tbody, ['B'])
  const third = tableRow(tbody, ['C', 'New', '$30'])
  assert.deepEqual(collectTable([first, second, third]).rows, [
    ['A', 'Shared', '$10'], ['B', 'Shared', ''], ['C', 'New', '$30'],
  ])
})

test('minimal colspan positioning keeps rowspan and following fields aligned', () => {
  const tbody = new ElementNode('tbody')
  const first = tableRow(tbody, ['Group', 'A', '$10'], { 0: { rowspan: '2', colspan: '2' } })
  const second = tableRow(tbody, ['B', '$20'])
  const result = collectTable([first, second])
  assert.deepEqual(Array.from(result.fields, (field) => field.tableColumn), [0, 2, 3])
  assert.deepEqual(result.rows, [['Group', 'A', '$10'], ['Group', 'B', '$20']])
})

test('span accounting includes unmatched preceding rows and never leaks between tbody groups', () => {
  const firstBody = new ElementNode('tbody')
  tableRow(firstBody, ['Group', 'Skipped', '$0'], { 0: { rowspan: '0' } })
  const first = tableRow(firstBody, ['A', '$10'])
  const second = tableRow(firstBody, ['B', '$20'])
  const other = tableRow(new ElementNode('tbody'), ['Other', 'C', '$30'])
  for (const row of [first, second, other]) {
    row.classes.push('data')
    row.classList.length = 1
  }
  const { detect, build } = page([first, second, other])
  const fields = detect('tr', ['data'], pageUrl).fields
  assert.deepEqual(Array.from(fields, (field) => field.sampleValue), ['Group', 'A', '$10'])
  const result = build('tr', ['data'], pageUrl, fields)
  assert.deepEqual(Array.from(result.rows, (row) => Array.from(row)), [
    ['Group', 'A', '$10'], ['Group', 'B', '$20'], ['Other', 'C', '$30'],
  ])
})

test('uses occurrence for repeated selectors and reports missing data', () => {
  const first = card('One', null)
  first.append(new ElementNode('span', ['value']).addText('First'))
  first.append(new ElementNode('span', ['value']).addText('Second'))
  const second = card('Two', null)
  second.append(new ElementNode('span', ['value']).addText('Third'))
  second.append(new ElementNode('span', ['value']).addText('Fourth'))

  const { detect, build } = page([first, second])
  const fields = detect('article', ['product_pod'], pageUrl).fields
    .filter((field) => field.selector === ':scope span.value')
  assert.equal(fields.map((field) => field.occurrence).join(','), '0,1')
  const result = build('article', ['product_pod'], pageUrl, fields)
  assert.equal(result.status, 'success')
  assert.equal(result.rows.map((row) => row.join(',')).join('|'), 'First,Second|Third,Fourth')

  const missingPrice = {
    id: 'missing', type: 'text', selector: ':scope p.price', occurrence: 0,
    sampleValue: '£51.77',
  }
  assert.equal(build('article', ['product_pod'], pageUrl, [missingPrice]).status, 'fieldMissing')
  assert.equal(page([]).build('article', ['product_pod'], pageUrl, fields).status, 'noCards')
  assert.equal(page([first], 'https://example.test/other').build(
    'article', ['product_pod'], pageUrl, fields,
  ).status, 'pageChanged')
})
