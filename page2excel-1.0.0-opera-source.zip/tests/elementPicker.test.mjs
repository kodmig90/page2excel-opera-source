import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

function loadModule(path, globals) {
  const source = readFileSync(new URL(path, import.meta.url), 'utf8')
  const output = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS },
  }).outputText
  const context = { exports: {}, ...globals }
  vm.runInNewContext(output, context)
  return context.exports
}

class ElementNode {
  constructor(tag, parent = null, classes = []) {
    this.tagName = tag.toUpperCase()
    this.parentElement = parent
    this.classList = classes
    this.id = ''
    this.innerText = ' Example text '
    this.textContent = ''
    this.isConnected = true
    this.style = {}
    this.children = []
    this.offsetWidth = 180
    this.offsetHeight = 50
    this.rect = { left: 700, top: 540, bottom: 570, width: 60, height: 30 }
  }
  append(...children) { this.children.push(...children) }
  remove() { this.isConnected = false }
  setAttribute() {}
  getBoundingClientRect() { return this.rect }
}

function setup() {
  const html = new ElementNode('html')
  const body = new ElementNode('body', html)
  const table = new ElementNode('table', body)
  const row = new ElementNode('tr', table, ['product-row'])
  const cell = new ElementNode('td', row, ['price'])
  const listeners = new Map()
  const stored = {}
  const window = {
    innerWidth: 800, innerHeight: 600,
    location: { href: 'https://example.test' },
    addEventListener(type, handler) {
      if (!listeners.has(type)) listeners.set(type, new Set())
      listeners.get(type).add(handler)
    },
    removeEventListener(type, handler) { listeners.get(type)?.delete(handler) },
    setTimeout() { return 1 },
    clearTimeout() {},
  }
  const document = { documentElement: html, body, title: 'Example', createElement: (tag) => new ElementNode(tag) }
  const chrome = { storage: { session: { async set(value) { Object.assign(stored, value) } } } }
  const { startElementPicker } = loadModule('../src/content/elementPicker.ts', {
    window, document, chrome, Element: ElementNode, HTMLElement: ElementNode,
  })
  const messages = {
    selected: 'Selected', cancelled: 'Cancelled', error: 'Error', instructions: 'Instructions',
    elementTypes: { td: 'Table cell', tr: 'Table row' }, unknownElement: 'Page element',
  }
  function start() { startElementPicker('selectedElement:7', messages) }
  async function dispatch(type, target = cell, key) {
    const event = {
      key, button: 0, composedPath: () => [target],
      prevented: false, stopped: false,
      preventDefault() { this.prevented = true },
      stopImmediatePropagation() { this.stopped = true },
    }
    for (const handler of [...(listeners.get(type) ?? [])]) await handler(event)
    return event
  }
  return { start, dispatch, html, body, table, row, cell, listeners, stored }
}

test('arrows navigate parents and back, stop at body, reset on mouse movement, and select the highlighted parent', async () => {
  const picker = setup()
  picker.start()
  const [highlight, instructions, tooltip] = picker.html.children
  instructions.rect = { left: 600, right: 792, top: 450, bottom: 592 }
  assert.equal(instructions.textContent, 'Instructions')
  assert.match(instructions.style.cssText, /position: fixed/)
  assert.match(instructions.style.cssText, /font-size: 15px/)
  assert.match(instructions.style.cssText, /white-space: pre-line/)
  assert.match(tooltip.style.cssText, /pointer-events: none/)
  await picker.dispatch('mousemove')
  assert.equal(tooltip.children[0].textContent, 'Table cell')
  assert.equal(tooltip.children[1].textContent, 'td.price')
  assert.ok(Number.parseFloat(tooltip.style.left) + tooltip.offsetWidth <= 800)
  assert.ok(Number.parseFloat(tooltip.style.top) + tooltip.offsetHeight <= 600)
  assert.ok(Number.parseFloat(tooltip.style.top) + tooltip.offsetHeight < instructions.rect.top)
  const up = await picker.dispatch('keydown', picker.cell, 'ArrowUp')
  assert.ok(up.prevented && up.stopped)
  assert.equal(tooltip.children[1].textContent, 'tr.product-row')
  await picker.dispatch('keydown', picker.cell, 'ArrowUp')
  await picker.dispatch('keydown', picker.cell, 'ArrowUp')
  await picker.dispatch('keydown', picker.cell, 'ArrowUp')
  assert.equal(tooltip.children[1].textContent, 'body')
  assert.equal(tooltip.children[0].textContent, 'Page element')
  await picker.dispatch('keydown', picker.cell, 'ArrowDown')
  assert.equal(tooltip.children[1].textContent, 'table')
  await picker.dispatch('mousemove')
  await picker.dispatch('keydown', picker.cell, 'ArrowDown')
  assert.equal(tooltip.children[1].textContent, 'td.price')
  await picker.dispatch('keydown', picker.cell, 'ArrowUp')
  const click = await picker.dispatch('click')
  assert.ok(click.prevented && click.stopped)
  assert.equal(picker.stored['selectedElement:7'].tagName, 'tr')
  assert.deepEqual(Array.from(picker.stored['selectedElement:7'].classes), ['product-row'])
  assert.equal(highlight.isConnected, false)
  assert.equal(instructions.isConnected, false)
  assert.equal(tooltip.isConnected, false)
  assert.ok([...picker.listeners.values()].every((handlers) => handlers.size === 0))
})

test('restarting removes the previous picker; Escape cleans up without saving', async () => {
  const picker = setup()
  picker.start()
  const oldOverlays = [...picker.html.children]
  picker.start()
  assert.ok(oldOverlays.every((node) => !node.isConnected))
  assert.equal(picker.listeners.get('mousemove').size, 1)
  const pointer = await picker.dispatch('pointerdown')
  assert.ok(pointer.prevented && pointer.stopped)
  await picker.dispatch('mousemove')
  await picker.dispatch('keydown', picker.cell, 'Escape')
  assert.deepEqual(picker.stored, {})
  assert.ok([...picker.listeners.values()].every((handlers) => handlers.size === 0))
  assert.ok(picker.html.children.slice(3, 6).every((node) => !node.isConnected))
})

test('reset removes all five chain keys only for the requested tab', async () => {
  const prefixes = ['selectedElement', 'similarElements', 'detectedFields', 'columns', 'preparedTable']
  const stored = Object.fromEntries(prefixes.flatMap((prefix) => [[`${prefix}:7`, true], [`${prefix}:8`, true]]))
  const { resetTabSelection } = loadModule('../src/resetSelection.ts', {
    chrome: { storage: { session: { async remove(keys) { for (const key of keys) delete stored[key] } } } },
  })
  await resetTabSelection(7)
  assert.deepEqual(Object.keys(stored).sort(), prefixes.map((prefix) => `${prefix}:8`).sort())
})
