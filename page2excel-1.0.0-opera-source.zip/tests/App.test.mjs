import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

// Exercise popup handlers and rendered controls without a browser or new test dependencies.
const output = ts.transpileModule(readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8'), {
  compilerOptions: {
    target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX,
  },
}).outputText
const url = 'https://example.test/products'
const identity = { url, tagName: 'article', classes: ['card'] }
const fields = [
  { id: 'price', type: 'text', selector: ':scope p.price', occurrence: 0, sampleValue: '$10' },
  { id: 'ignored', type: 'imageAlt', selector: ':scope img', occurrence: 0, sampleValue: 'Image' },
  { id: 'name', type: 'text', selector: ':scope h2', occurrence: 0, sampleValue: 'Product' },
]
const columns = [
  { fieldId: 'price', selected: true, columnName: 'Моя цена' },
  { fieldId: 'ignored', selected: false, columnName: 'Не экспортировать' },
  { fieldId: 'name', selected: true, columnName: 'Название товара' },
]
const clone = (value) => JSON.parse(JSON.stringify(value))

function popup(saved) {
  const stored = clone(saved ?? {
    'selectedElement:1': { ...identity, id: '', text: 'Product', title: 'Products' },
    'similarElements:1': { ...identity, count: 10 },
    'detectedFields:1': { ...identity, fields, truncated: false },
    'columns:1': columns,
  })
  const writes = []
  const injections = []
  const state = []
  let cursor = 0
  let mounted = false
  let effect
  let count = 10
  let resultStatus = 'success'
  const exporter = { downloadXlsx: async () => {} }
  const buildTable = function buildTable() {}
  const installRepeatedElementResolver = function installRepeatedElementResolver() {}
  const chrome = {
    runtime: { getManifest: () => ({ version: '1.0.0' }) },
    i18n: { getMessage: (key, args) => args === undefined ? key : `${key}:${[args].flat().join(',')}` },
    tabs: { query: async () => [{ id: 1, url }] },
    storage: { session: {
      get: async () => clone(stored),
      set: async (values) => { writes.push(clone(values)); Object.assign(stored, clone(values)) },
      remove: async (keys) => { for (const key of [keys].flat()) delete stored[key] },
    } },
    scripting: { executeScript: async (injection) => {
      injections.push(injection)
      assert.ok([buildTable, installRepeatedElementResolver].includes(injection.func))
      return injection.func === buildTable ? [{ result: {
        status: resultStatus, url,
        rows: Array.from({ length: count }, (_, index) => [`$${index}`, `Product ${index}`]),
      } }] : []
    } },
  }
  const jsx = (type, props) => ({ type, props })
  const context = { exports: {}, chrome, require(name) {
    if (name === 'react') return {
      useState(initial) {
        const index = cursor++
        if (!(index in state)) state[index] = initial
        return [state[index], (value) => { state[index] = value }]
      },
      useEffect(callback) { if (!mounted) effect = callback },
    }
    if (name === 'react/jsx-runtime') return { jsx, jsxs: jsx }
    if (name === './content/buildTable') return { buildTable }
    if (name === './content/repeatedElements') return { installRepeatedElementResolver }
    if (name === './export/xlsx') return exporter
    return {}
  } }
  vm.runInNewContext(output, context)
  function render() {
    cursor = 0
    const tree = context.exports.default()
    mounted = true
    return tree
  }
  function nodes(node = render()) {
    if (!node || typeof node !== 'object') return []
    return [node, ...[node.props?.children].flat(Infinity)
      .filter((child) => child !== undefined).flatMap((child) => nodes(child))]
  }
  function button(label) { return nodes().find((node) => node.type === 'button' && node.props.children === label) }
  return {
    stored, writes, injections, exporter, nodes, button,
    setCount(value) { count = value },
    setStatus(value) { resultStatus = value },
    async load() { render(); effect(); await new Promise((resolve) => setImmediate(resolve)) },
  }
}

test('prepare and refresh share a handler, preserve columns, and save table and count together', async () => {
  const app = popup()
  await app.load()
  await app.button('prepareTable').props.onClick()
  app.setCount(20)
  const actions = app.nodes().filter((node) => node.type === 'button')
  assert.equal(actions.find((node) => node.props.children === 'prepareTable').props.onClick,
    actions.find((node) => node.props.children === 'refreshTable').props.onClick)
  await app.button('refreshTable').props.onClick()
  const savedTable = app.stored['preparedTable:1']
  assert.equal(savedTable.rows.length, 20)
  assert.equal(app.stored['similarElements:1'].count, 20)
  assert.deepEqual(savedTable.columns, [
    { fieldId: 'price', columnName: 'Моя цена' },
    { fieldId: 'name', columnName: 'Название товара' },
  ])
  assert.deepEqual(app.stored['columns:1'], columns)
  assert.deepEqual(app.stored['detectedFields:1'].fields, fields)
  for (const write of app.writes) {
    assert.ok(write['preparedTable:1'] && write['similarElements:1'])
    assert.equal(write['preparedTable:1'].rows.length, write['similarElements:1'].count)
  }
  const builds = app.injections.filter((injection) => injection.args)
  assert.equal(builds.length, 2)
  assert.deepEqual(clone(builds[1].args[3]).map((field) => field.id), ['price', 'name'])
  assert.ok(app.nodes().some((node) => node.props?.children === 'fullExportNotice:20'))
  assert.ok(app.nodes().some((node) => node.props?.children === 'tableSummary:20,2'))
  app.setCount(1)
  await app.button('refreshTable').props.onClick()
  assert.equal(app.stored['similarElements:1'].count, 1)
  assert.equal(app.stored['preparedTable:1'].rows.length, 1)
  assert.ok(app.nodes().some((node) => node.props?.children === 'noSimilarElements'))
  const reopened = popup(app.stored)
  await reopened.load()
  assert.ok(reopened.button('refreshTable'))
  assert.ok(reopened.button('downloadXlsx'))
})

test('failed refresh removes the saved table and export actions but keeps column settings', async () => {
  for (const [status, message] of [
    ['noCards', 'noRepeatedElements'], ['fieldMissing', 'selectedFieldMissing'], ['pageChanged', 'selectionPageChanged'],
  ]) {
    const app = popup()
    await app.load()
    await app.button('prepareTable').props.onClick()
    app.setStatus(status)
    await app.button('refreshTable').props.onClick()
    assert.equal(app.stored['preparedTable:1'], undefined)
    assert.equal(app.button('downloadXlsx'), undefined)
    assert.equal(app.button('downloadCsv'), undefined)
    assert.deepEqual(app.stored['columns:1'], columns)
    assert.ok(app.nodes().some((node) => node.props?.children === message))
    assert.ok(app.button('prepareTable'))
  }
})

test('XLSX progress label and busy controls reset after success and failure', async () => {
  for (const fails of [false, true]) {
    const app = popup()
    await app.load()
    await app.button('prepareTable').props.onClick()
    let finish
    app.exporter.downloadXlsx = () => new Promise((resolve, reject) => {
      finish = () => fails ? reject(new Error('Export failed')) : resolve()
    })
    const exporting = app.button('downloadXlsx').props.onClick()
    assert.ok(app.button('preparingXlsx').props.disabled)
    assert.ok(app.button('refreshTable').props.disabled)
    assert.ok(app.nodes().filter((node) => node.type === 'input').every((node) => node.props.disabled))
    finish()
    await exporting
    assert.equal(app.button('preparingXlsx'), undefined)
    assert.equal(app.button('downloadXlsx').props.disabled, false)
    assert.ok(app.nodes().filter((node) => node.type === 'input' && node.props.type === 'checkbox')
      .every((node) => !node.props.disabled))
    assert.equal(app.nodes().some((node) => node.props?.children === 'xlsxExportError'), fails)
  }
})
