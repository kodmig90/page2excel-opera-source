import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

const source = readFileSync(new URL('../src/export/xlsx.ts', import.meta.url), 'utf8')
const output = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS },
}).outputText
const context = { exports: {} }
vm.runInNewContext(output, context)
const { prepareXlsxData } = context.exports

test('prepares headers and all rows as text, preserving Russian, empty values, and URLs', () => {
  const rows = [
    ['Книга', 'https://example.test/book', ''],
    ['Вторая книга', '', '£51.77'],
  ]
  const data = prepareXlsxData(
    [{ columnName: 'Название' }, { columnName: 'Ссылка' }, { columnName: 'Цена' }],
    rows,
  )

  assert.equal(data.length, rows.length + 1)
  assert.deepEqual(
    Array.from(data, (row) => Array.from(row, (cell) => cell.value)),
    [['Название', 'Ссылка', 'Цена'], ...rows],
  )
  assert.ok(data[0].every((cell) => cell.fontWeight === 'bold'))
  assert.ok(data.every((row) => row.every((cell) => cell.type.name === 'String')))
})

test('rejects missing or malformed table data before file generation', () => {
  assert.throws(() => prepareXlsxData([], [['value']]))
  assert.throws(() => prepareXlsxData([{ columnName: 'Name' }], []))
  assert.throws(() => prepareXlsxData([{ columnName: 'Name' }], [['a', 'b']]))
  assert.throws(() => prepareXlsxData([{ columnName: 'Name' }], [[null]]))
})
