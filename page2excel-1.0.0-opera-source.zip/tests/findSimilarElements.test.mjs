import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import test from 'node:test'
import vm from 'node:vm'
import ts from 'typescript'

const source = readFileSync(new URL('../src/content/findSimilarElements.ts', import.meta.url), 'utf8')
const output = ts.transpileModule(source, {
  compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS },
}).outputText
const exportsContext = { exports: {} }
vm.runInNewContext(output, exportsContext)
const findSource = exportsContext.exports.findSimilarElements.toString()
const resolverOutput = ts.transpileModule(
  readFileSync(new URL('../src/content/repeatedElements.ts', import.meta.url), 'utf8'),
  { compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.CommonJS } },
).outputText
const resolverContext = { exports: {} }
vm.runInNewContext(resolverOutput, resolverContext)
const installSource = resolverContext.exports.installRepeatedElementResolver.toString()
const url = 'https://example.test/table'

class ElementNode {
  constructor(tag, parent = null, text = '', classes = [], id = '') {
    this.tagName = tag.toUpperCase()
    this.parentElement = parent
    this.children = []
    this.nodeType = 1
    this.childNodes = text ? [{ nodeType: 3, textContent: text }] : []
    parent?.children.push(this)
    parent?.childNodes.push(this)
    this.innerText = text
    this.id = id
    this.isConnected = true
    this.classList = { length: classes.length, contains: (name) => classes.includes(name) }
    this.style = {}
  }
  getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 20 } }
  remove() { this.isConnected = false }
}

function page(elements, selected) {
  const overlays = []
  const context = {
    HTMLElement: ElementNode,
    window: {
      location: { href: url }, __page2excelSelectedElement: selected,
      setTimeout: () => 1, clearTimeout() {}, addEventListener() {}, removeEventListener() {},
    },
    document: {
      getElementsByTagName: (tag) => elements.filter((element) => element.tagName.toLowerCase() === tag),
      getElementById: (id) => elements.find((element) => element.id === id),
      createElement: (tag) => new ElementNode(tag),
      createDocumentFragment: () => ({ append: (element) => overlays.push(element) }),
      documentElement: { append() {} },
    },
  }
  vm.runInNewContext(`(${installSource})()`, context)
  return { find: vm.runInNewContext(`(${findSource})`, context), overlays,
    signature: context.window.__page2excelStructuralSignature }
}

test('classless rows match only direct siblings of the selected tbody', () => {
  const first = new ElementNode('tbody')
  const second = new ElementNode('tbody')
  const selected = new ElementNode('tr', first, 'Same text')
  const sibling = new ElementNode('tr', first, 'Second row')
  const styledSibling = new ElementNode('tr', first, 'Third row', ['row'])
  const unrelated = new ElementNode('tr', second, 'Same text')
  const sample = page([selected, sibling, styledSibling, unrelated], selected)
  assert.equal(sample.find('tr', [], url, { id: '', text: 'Same text' }).count, 3)
  assert.equal(sample.overlays.length, 3)
})

test('restores a selected node from unique saved text without including another tbody', () => {
  const first = new ElementNode('tbody')
  const second = new ElementNode('tbody')
  const selected = new ElementNode('tr', first, ' Unique   row ')
  const sibling = new ElementNode('tr', first, 'Second row')
  const unrelated = new ElementNode('tr', second, 'Other row')
  assert.equal(page([selected, sibling, unrelated]).find('tr', [], url, { id: '', text: 'Unique row' }).count, 2)
})

test('isolated or ambiguous classless elements do not cause a document-wide match', () => {
  const parent = new ElementNode('div')
  const only = new ElementNode('p', parent, 'Only')
  assert.equal(page([only], only).find('p', [], url, { id: '', text: 'Only' }).count, 1)
  const orphan = new ElementNode('p', null, 'Orphan')
  assert.equal(page([orphan], orphan).find('p', [], url, { id: '', text: 'Orphan' }).insufficient, true)
  const duplicate = new ElementNode('p', new ElementNode('div'), 'Only')
  assert.equal(page([only, duplicate]).find('p', [], url, { id: '', text: 'Only' }).insufficient, true)
})

test('elements with classes still match the exact class set across the page', () => {
  const first = new ElementNode('a', new ElementNode('div'), '', ['card', 'item'])
  const second = new ElementNode('a', new ElementNode('div'), '', ['item', 'card'])
  const extra = new ElementNode('a', null, '', ['card', 'item', 'extra'])
  assert.equal(page([first, second, extra]).find('a', ['card', 'item'], url).count, 2)
})

function product(parent, index) {
  const root = new ElementNode('div', parent, '', [`hash-${index}`], `product-${index}`)
  new ElementNode('div', root, `Product ${index}`, [`name-${index}`])
  new ElementNode('div', root, `Category ${index}`, [`category-${index}`])
  new ElementNode('div', root, `$${index * 10}`, [`price-${index}`])
  return root
}

test('structural fallback finds ten sibling products despite different classes, IDs, and values', () => {
  const container = new ElementNode('div')
  const products = Array.from({ length: 10 }, (_, index) => product(container, index))
  const ad = new ElementNode('div', container, '', ['ad'])
  new ElementNode('p', ad, 'Advertisement')
  const outside = product(new ElementNode('div'), 20)
  const sample = page([...products, ad, outside], products[0])
  assert.equal(sample.find('div', ['hash-0'], url).count, 10)
  assert.equal(sample.overlays.length, 10)
  assert.equal(sample.signature(products[0]), sample.signature(products[9]))
  assert.notEqual(sample.signature(products[0]), sample.signature(ad))
})

test('structure comparison distinguishes text placement, child order, and nesting', () => {
  const first = new ElementNode('div')
  new ElementNode('span', first, 'A')
  new ElementNode('p', first, 'B')
  const reordered = new ElementNode('div')
  new ElementNode('p', reordered, 'B')
  new ElementNode('span', reordered, 'A')
  const nested = new ElementNode('div')
  new ElementNode('p', new ElementNode('span', nested), 'B')
  const { signature } = page([])
  assert.notEqual(signature(first), signature(reordered))
  assert.notEqual(signature(first), signature(nested))
  const before = signature(first)
  first.childNodes.unshift({ nodeType: 3, textContent: 'Inline label' })
  assert.notEqual(signature(first), before)
})

test('multiple exact matches retain priority over structural siblings', () => {
  const container = new ElementNode('div')
  const first = product(container, 0)
  const second = product(container, 1)
  second.classList = first.classList
  const other = product(container, 2)
  assert.equal(page([first, second, other], first).find('div', ['hash-0'], url).count, 2)
})
